package com.example.slamapp;

import android.content.Context;

import java.io.IOException;
import java.util.Arrays;

import Jama.Matrix;

public class EKFSLAMalgo {

    public double[] standard_odemetry_model(double pose[], double odometry[]){///pose is the known postion and the odometry is the readings recieved
        double rx=pose[0];
        double ry=pose[1];
        double rtheta=pose[2];
        double trans= Math.sqrt((rx*rx)+(ry*ry));

        double Ox = odometry[0];
        double Oy= odometry[1];

        double r1 = Math.atan(Ox/Oy);
        double r2 = 0;

        rx += trans*Math.cos(r1);
        ry += trans*Math.sin(r1);
        rtheta += r1+r2;

        double fpose[] = new double[3];
        fpose[0]=rx;
        fpose[1]=ry;
        fpose[2]=rtheta;
        return fpose;//returns the device motion update
    }

    public double[] range_bearing_model(double robot_pose[], double range_bearing[]){
        double [] mpos = new double[2];
        double rx=robot_pose[0];
        double ry=robot_pose[1];
        double rtheta=robot_pose[2];
        double range = range_bearing[0];
        double bearing = range_bearing[1];


        double mx = rx+range*Math.cos(bearing+rtheta);
        double my = rx+range*Math.sin(bearing+rtheta);
        mpos[0]=mx;
        mpos[1]=my;

        return mpos;
    }

    public double [] belief_init_mu(int nLandmarks) {
        int mSize = 3 + 2 * nLandmarks;
        double[] mu = new double[mSize];
        for (int i = 0; i < mSize; i++) {
            mu[i]=0;
        }
        return mu;
    }

    public double[][] belief_init_sigma(int nLandmarks) {
        int mSize = 3 + 2 * nLandmarks;
        double[][] Sigma = new double[mSize][mSize];
        for (int i = 0; i < mSize; i++) {
            for (int j = 0; j < mSize; j++) {
                Sigma[i][j] = 0;
            }
        }
        return Sigma;
    }

    public double[] prediction_step_mu(double belief_sigma[][], double belief_mu[], double[] odometry, double noise[]){
        double rx=belief_mu[0];
        double ry=belief_mu[1];
        double rtheta=belief_mu[2];
        //Compute the new mu based on the noise-free (odometry-based) motion model
        double[] Npose = standard_odemetry_model(belief_mu, odometry);
         return Npose;
    }

    public double[][] prediction_step_sigma(double belief_sigma[][], double belief_mu[], double[] odometry, double noise[],int nLandmarks){
        int mSize =belief_sigma.length;
        double rx=belief_mu[0];
        double ry=belief_mu[1];
        double rtheta=belief_mu[2];
        double [][] MSigmaXX = new double[3][3];
        double [][] MSigmaXM = new double [3][mSize];


        //Compute the 3x3 Jacobian Gx of the motion model
        double Gx[][] = new double[3][3];
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                Gx[r][c]=0;
            }
        }
        Gx[0][0]=1;
        Gx[1][1]=1;
        Gx[2][2]=1;
        double Ox = odometry[0];
        double Oy= odometry[1];
        double r1 = Math.atan(Ox/Oy);
        double trans= Math.sqrt((rx*rx)+(ry*ry));
        double heading = rtheta+r1;
        Gx[0][2]=trans*Math.sin(heading);
        Gx[1][2]=trans*Math.cos(heading);

        //Motion Noise
        double Rx[][] = new double[3][3];
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                Rx[r][c]=0;
            }
        }
        Rx[0][0]=noise[0];//noise of sensor getting x
        Rx[1][1]=noise[1];//noise of sensor getting y
        Rx[2][2]=noise[2];//noise of sensor getting theta

        //Compute the predicted sigma after incorporating the motion

        double sigmaXX;
        double sigmaXM;
        double [][] NewSigma = new double[mSize][mSize];
        Matrix MGx= new Matrix(Gx);
        //Transposing Gx
        Matrix MTGx = MGx.transpose();
        double[][] TGx=MTGx.getArray();


        //Gets the requires SIGMAXX and SIGMAXM from belief_sigma
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                MSigmaXX[i][j]=belief_sigma[i][j];
            }
        }

        for (int i = 0; i < 3; i++) {
            for (int j = 3; j < mSize; j++) {
                MSigmaXM[i][j]=belief_sigma[i][j];
            }
        }

        Matrix MMSigmaXX=new Matrix(MSigmaXX);
        Matrix MRx =new Matrix(Rx);
        Matrix Mans = MGx.times(MMSigmaXX).times(MTGx).plus(MRx);//
        double [][] FMSigmaXX= Mans.getArray();


        double [][] FMSigmaXM = new double[3][mSize];
        for (int i = 0; i < 3; i++) { //setting all values to zero
            for (int j = 0; j < mSize; j++) {
                FMSigmaXM[i][j] = 0;
            }
        }
        //multiplying Gx and MSigmaXM
        MGx= new Matrix(Gx);
        Matrix MMSigmaXM=new Matrix(MSigmaXM);
        System.out.println("Gx col= "+MGx.getColumnDimension()+" Gx row= "+MGx.getRowDimension());
        System.out.println("MMSigmaXM col= "+MMSigmaXM.getColumnDimension()+" MMSigmaXM row= "+MMSigmaXM.getRowDimension());
        Matrix FMSxm = MGx.times(MMSigmaXM);
        FMSigmaXM= FMSxm.getArray();

        double [][] FSigma= new double [mSize][mSize];//final sigma

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                FSigma[i][j] = FMSigmaXX[i][j];
            }
        }
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                FSigma[i][j] =  FSigma[i][j]+FMSigmaXM[i][j];
            }
        }
        return FSigma;
    }


    public double[] correction_step_mu(double belief_sigma[][],double belief_mu[],double range_bearings[], double noises[]){// bearings is the observations against the pos and the landmark
        double rx=belief_mu[0];
        double ry=belief_mu[1];
        double [] f_mu = new double [2];
        double rtheta=belief_mu[2];
        double mx,my,sqrtq;
        double [] delta = new double [2];
        int nRangeBearings = range_bearings.length;
        int nBelief_mu = belief_mu.length;
        double [][] H = new double[nRangeBearings][nBelief_mu];
        double [][] tH = new double[nBelief_mu][nRangeBearings];
        double [] tZS = new double[0];//true observations
        double [] pZS = new double[0];//predicted observations
        double [][] Hi = new double[2][nBelief_mu];
        System.out.println("nBelief_mu= "+nBelief_mu);
        System.out.println("2*nRangeBearings= "+2*nRangeBearings);
        double [][] Q = new double[nRangeBearings][nRangeBearings];
        double range = range_bearings[0];//getting the range
        double bearings = range_bearings[1];//getting the bearing
        int landmarkID = (int) range_bearings[2];//getting id of
        double noise=noises[0];
        System.out.println("nRangeBearings= "+nRangeBearings);

        Matrix MMU = new Matrix(belief_mu,1);
        System.out.println("MMU col= "+MMU.getColumnDimension()+" MMU row= "+MMU.getRowDimension());
        Matrix TMMU = MMU.transpose();
        Matrix MSIGMA = new Matrix(belief_sigma);


        //Construct the sensor noise matrix Q
        for (int i = 0; i <nRangeBearings; i++) { //setting all values in Q to 0
            for (int j = 0; j < nRangeBearings; j++) {
                Q[i][j] = 0;
            }
        }
        for (int i = 0; i<nRangeBearings; i++) {//setting all the diagonal values to 1
            Q[i][i] = 1;
        }
        for (int i = 0; i <nRangeBearings; i++) { //placing the noise value in the matrix
            for (int j = 0; j < nRangeBearings; j++) {
                Q[i][j] = Q[i][j]*noise;
            }
        }

        for (int i = 0; i < 2; i++) { //setting all values in Hi to 0
            for (int j = 0; j < nBelief_mu; j++) {
                Hi[i][j] = 0;
            }
        }


        for(int i=0; i<range_bearings.length/2;i++){//repeats for every observed feature(landmarks)

            int LID = i;//landmark ID from range bearings

            System.out.println("belief_mu row= "+belief_mu.length);
            if (belief_mu[2*LID+1]==0){
                // Initialize its pose in mu based on the measurement and the current robot pose
                double rbm[]=range_bearing_model(belief_mu, range_bearings);
                belief_mu[2*LID+1]=rbm[0];
                belief_mu[2*LID+2]=rbm[1];

            }

            // Add the landmark measurement to the Z vector
            tZS = Arrays.copyOf(tZS, tZS.length + 2);
            tZS[tZS.length - 2]=range;
            tZS[tZS.length - 1] = bearings;


            // Use the current estimate of the landmark pose
            //to compute the corresponding expected measurement in pZS:
            mx=belief_mu[2*LID+1];
            my=belief_mu[2*LID+2];
            delta[0]=mx*rx;
            delta[1]=my-ry;

            double q = 0;
            for (int k = 0; k < delta.length; k++){//calculating the dot product of delta
                q += delta[k] * delta[k];
            }
            sqrtq=Math.sqrt(q);

            pZS = Arrays.copyOf(pZS, pZS.length + 2);
            pZS[pZS.length - 2]=sqrtq;
            pZS[pZS.length - 1] = Math.atan(delta[1]/delta[0])-rtheta;

            System.out.println("LID= "+LID);
            System.out.println("Hi row= "+Hi.length+" Hi col= "+Hi[0].length);
            System.out.println("nBelief_mu= "+nBelief_mu);

             // Compute the Jacobian Hi of the measurement function h for this observation
            double deltax = delta[0];
            double deltay = delta[1];
            Hi[0][0]=-sqrtq*deltax;
            Hi[0][1]=-sqrtq*deltay;
            Hi[0][2]=0;
            Hi[1][0]=deltay;
            Hi[1][1]=-deltax;
            Hi[1][2]=-q;
            Hi[0][2*LID+3]=sqrtq*deltax;
            Hi[0][2*LID+4]=sqrtq*deltay;
            Hi[1][2*LID+3]=-deltay;
            Hi[1][2*LID+4]=deltax;



            for (int n = 0; n < Hi.length; n++) { //dividing by q
                for (int j = 0; j < Hi[0].length; j++) {
                    Hi[n][j] = (Hi[n][j])/q;
                }
            }
            System.out.println("Hi.length= "+Hi.length);


            //Augment H with the new Hi

            for (int n=0; n<nBelief_mu; n++){
                H[2*i][n]=Hi[0][n];
                H[2*i+1][n]=Hi[1][n];
            }
        }
        System.out.println("nBelief_mu= "+nBelief_mu);

        Matrix MH = new Matrix(H);
        Matrix MtH = MH.transpose();//transposw of matrix H
        System.out.println("MtH col= "+MtH.getColumnDimension()+" MtH row= "+MtH.getRowDimension());


        //Compute the Kalman gain K

        Matrix Mbelief_sigma = new Matrix(belief_sigma);
        System.out.println("Mbelief_sigma col= "+Mbelief_sigma.getColumnDimension()+" Mbelief_sigma row= "+Mbelief_sigma.getRowDimension());
        //Matrix MtH = new Matrix(tH);
        //Matrix MH = new Matrix(H);
        Matrix MQ = new Matrix(Q);

        Matrix ans1 = Mbelief_sigma.times(MtH);//belief_sigma*tH
        System.out.println("ans1 col= "+ans1.getColumnDimension()+" ans1 row= "+ans1.getRowDimension());
        Matrix ans2 = MH.times(Mbelief_sigma).times(MtH).plus(MQ);//H*belief_sigma*tH+Q
        System.out.println("ans2 col= "+ans2.getColumnDimension()+" ans2 row= "+ans2.getRowDimension());
        Matrix Ians2 = ans2.inverse();//Gets inverse of ans2
        Matrix MK = ans1.times(Ians2);//ans*Ians2
        double [][] K= MK.getArray();

        //Compute the difference between the expected and recorded measurements.
        double [] deltaZ= new double[tZS.length];
        for (int n=0; n<deltaZ.length;n++){
            deltaZ[n]=tZS[n]-pZS[n];
        }

        //Finish the correction step by computing the new mu and sigma.
        Matrix MdeltaZ = new Matrix(deltaZ,1);
        System.out.println("MdeltaZ col= "+MdeltaZ.getColumnDimension()+" MdeltaZ row= "+MdeltaZ.getRowDimension());
        System.out.println("MK col= "+MK.getColumnDimension()+" MK row= "+MK.getRowDimension());
        System.out.println("tZS.length= "+tZS.length);

        //FIX MAYBE add 3 0s to the beginning of the MdeltaZ
        Matrix MTdeltaZ = MdeltaZ.transpose();

        Matrix KDZans = MK.times(MTdeltaZ);//k*deltaZ

        System.out.println("KDZans col= "+KDZans.getColumnDimension()+" KDZans row= "+KDZans.getRowDimension());
        System.out.println("MMU col= "+MMU.getColumnDimension()+" MMU row= "+MMU.getRowDimension());


        TMMU= TMMU.plus(KDZans);//adding K*delta Z to the previous belief_mu value
        double[][] final1_mu = TMMU.getArray();//final mean estimate

        double [] final_mu=new double[nBelief_mu];
        for(int i=0;i<nBelief_mu;i++){
            final_mu[i]=final1_mu[i][0];//swap this if not getting values
            System.out.println("final1_mu["+i+"][0]= "+final1_mu[i][0]);
        }

        Matrix I = Matrix.identity(nBelief_mu,nBelief_mu);//Making identity matrix of size nBelief_mu
        System.out.println("MH col= "+MH.getColumnDimension()+" MH row= "+MH.getRowDimension());
        System.out.println("MK col= "+MK.getColumnDimension()+" MK row= "+MK.getRowDimension());

        Matrix MSIGMAp1= I.minus(MK.times(MH));
        MSIGMA = MSIGMAp1.times(MSIGMA);//final Sigma/Covariance
        double[][] final_sigma = MSIGMA.getArray();
        return final_mu;
    }


    public double[][] correction_step_sigma(double belief_sigma[][],double belief_mu[],double range_bearings[], double noises[]){// bearings is the observations against the pos and the landmark
        double rx=belief_mu[0];
        double ry=belief_mu[1];
        double [] f_mu = new double [2];
        double rtheta=belief_mu[2];
        double mx,my,sqrtq;
        double [] delta = new double [2];
        int nRangeBearings = range_bearings.length;
        int nBelief_mu = belief_mu.length;
        double [][] H = new double[nRangeBearings][nBelief_mu];
        double [][] tH = new double[nBelief_mu][nRangeBearings];
        double [] tZS = new double[0];//true observations
        double [] pZS = new double[0];//predicted observations
        double [][] Hi = new double[2][nBelief_mu];
        System.out.println("nBelief_mu= "+nBelief_mu);
        System.out.println("2*nRangeBearings= "+2*nRangeBearings);
        double [][] Q = new double[nRangeBearings][nRangeBearings];
        double range = range_bearings[0];//getting the range
        double bearings = range_bearings[1];//getting the bearing
        int landmarkID = (int) range_bearings[2];//getting id of
        double noise=noises[0];
        System.out.println("nRangeBearings= "+nRangeBearings);

        Matrix MMU = new Matrix(belief_mu,1);
        System.out.println("MMU col= "+MMU.getColumnDimension()+" MMU row= "+MMU.getRowDimension());
        Matrix TMMU = MMU.transpose();
        Matrix MSIGMA = new Matrix(belief_sigma);

        //Construct the sensor noise matrix Q
        for (int i = 0; i <nRangeBearings; i++) { //setting all values in Q to 0
            for (int j = 0; j < nRangeBearings; j++) {
                Q[i][j] = 0;
            }
        }
        for (int i = 0; i<nRangeBearings; i++) {//setting all the diagonal values to 1
            Q[i][i] = 1;
        }
        for (int i = 0; i <nRangeBearings; i++) { //placing the noise value in the matrix
            for (int j = 0; j < nRangeBearings; j++) {
                Q[i][j] = Q[i][j]*noise;
            }
        }

        for (int i = 0; i < 2; i++) { //setting all values in Hi to 0
            for (int j = 0; j < nBelief_mu; j++) {
                Hi[i][j] = 0;
            }
        }


        for(int i=0; i<range_bearings.length/2;i++){//repeats for every observed feature(landmarks)

            int LID = i;//landmark ID from range bearings

            System.out.println("belief_mu row= "+belief_mu.length);
            if (belief_mu[2*LID+1]==0){
                // Initialize its pose in mu based on the measurement and the current robot pose
                double rbm[]=range_bearing_model(belief_mu, range_bearings);
                belief_mu[2*LID+1]=rbm[0];
                belief_mu[2*LID+2]=rbm[1];

            }

            // Add the landmark measurement to the Z vector
            tZS = Arrays.copyOf(tZS, tZS.length + 2);
            tZS[tZS.length - 2]=range;
            tZS[tZS.length - 1] = bearings;


            // Use the current estimate of the landmark pose
            //to compute the corresponding expected measurement in pZS:
            mx=belief_mu[2*LID+1];//DOUBLE CHECK THESE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            my=belief_mu[2*LID+2];
            delta[0]=mx*rx;
            delta[1]=my-ry;

            double q = 0;
            for (int k = 0; k < delta.length; k++){//calculating the dot product of delta
                q += delta[k] * delta[k];
            }
            sqrtq=Math.sqrt(q);

            pZS = Arrays.copyOf(pZS, pZS.length + 2);
            pZS[pZS.length - 2]=sqrtq;
            pZS[pZS.length - 1] = Math.atan(delta[1]/delta[0])-rtheta;

            System.out.println("LID= "+LID);
            System.out.println("Hi row= "+Hi.length+" Hi col= "+Hi[0].length);
            System.out.println("nBelief_mu= "+nBelief_mu);

            // Compute the Jacobian Hi of the measurement function h for this observation
            double deltax = delta[0];
            double deltay = delta[1];
            Hi[0][0]=-sqrtq*deltax;
            Hi[0][1]=-sqrtq*deltay;
            Hi[0][2]=0;
            Hi[1][0]=deltay;
            Hi[1][1]=-deltax;
            Hi[1][2]=-q;
            Hi[0][2*LID+3]=sqrtq*deltax;
            Hi[0][2*LID+4]=sqrtq*deltay;
            Hi[1][2*LID+3]=-deltay;
            Hi[1][2*LID+4]=deltax;



            for (int n = 0; n < Hi.length; n++) { //dividing by q
                for (int j = 0; j < Hi[0].length; j++) {
                    Hi[n][j] = (Hi[n][j])/q;
                }
            }
            System.out.println("Hi.length= "+Hi.length);


            //Augment H with the new Hi

            for (int n=0; n<nBelief_mu; n++){
                H[2*i][n]=Hi[0][n];
                H[2*i+1][n]=Hi[1][n];
            }
        }
        System.out.println("nBelief_mu= "+nBelief_mu);


        Matrix MH = new Matrix(H);
        Matrix MtH = MH.transpose();//transposw of matrix H
        System.out.println("MtH col= "+MtH.getColumnDimension()+" MtH row= "+MtH.getRowDimension());


        //Compute the Kalman gain K

        Matrix Mbelief_sigma = new Matrix(belief_sigma);
        System.out.println("Mbelief_sigma col= "+Mbelief_sigma.getColumnDimension()+" Mbelief_sigma row= "+Mbelief_sigma.getRowDimension());
        //Matrix MtH = new Matrix(tH);
        //Matrix MH = new Matrix(H);
        Matrix MQ = new Matrix(Q);

        Matrix ans1 = Mbelief_sigma.times(MtH);//belief_sigma*tH
        System.out.println("ans1 col= "+ans1.getColumnDimension()+" ans1 row= "+ans1.getRowDimension());
        Matrix ans2 = MH.times(Mbelief_sigma).times(MtH).plus(MQ);//H*belief_sigma*tH+Q
        System.out.println("ans2 col= "+ans2.getColumnDimension()+" ans2 row= "+ans2.getRowDimension());
        Matrix Ians2 = ans2.inverse();//Gets inverse of ans2
        Matrix MK = ans1.times(Ians2);//ans*Ians2
        double [][] K= MK.getArray();

        //Compute the difference between the expected and recorded measurements.
        double [] deltaZ= new double[tZS.length];
        for (int n=0; n<deltaZ.length;n++){
            deltaZ[n]=tZS[n]-pZS[n];
        }


        //Finish the correction step by computing the new mu and sigma.
        Matrix MdeltaZ = new Matrix(deltaZ,1);
        System.out.println("MdeltaZ col= "+MdeltaZ.getColumnDimension()+" MdeltaZ row= "+MdeltaZ.getRowDimension());
        System.out.println("MK col= "+MK.getColumnDimension()+" MK row= "+MK.getRowDimension());
        System.out.println("tZS.length= "+tZS.length);

        //FIX MAYBE add 3 0s to the beginning of the MdeltaZ
        Matrix MTdeltaZ = MdeltaZ.transpose();

        Matrix KDZans = MK.times(MTdeltaZ);//k*deltaZ

        System.out.println("KDZans col= "+KDZans.getColumnDimension()+" KDZans row= "+KDZans.getRowDimension());
        System.out.println("MMU col= "+MMU.getColumnDimension()+" MMU row= "+MMU.getRowDimension());



        TMMU= TMMU.plus(KDZans);//adding K*delta Z to the previous belief_mu value
        double[][] final1_mu = TMMU.getArray();//final mean estimate
        double [] final_mu=new double[nBelief_mu];
        for(int i=0;i<nBelief_mu;i++){
            final_mu[i]=final1_mu[i][0];//swap this if not getting values
        }


        Matrix I = Matrix.identity(nBelief_mu,nBelief_mu);//Making identity matrix of size nBelief_mu

        System.out.println("MH col= "+MH.getColumnDimension()+" MH row= "+MH.getRowDimension());
        System.out.println("MK col= "+MK.getColumnDimension()+" MK row= "+MK.getRowDimension());

        Matrix MSIGMAp1= I.minus(MK.times(MH));
        MSIGMA = MSIGMAp1.times(MSIGMA);//final Sigma/Covariance
        double[][] final_sigma = MSIGMA.getArray();
        return final_sigma;
    }


}
