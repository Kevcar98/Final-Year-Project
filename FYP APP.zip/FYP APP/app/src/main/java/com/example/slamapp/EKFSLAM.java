package com.example.slamapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class EKFSLAM extends AppCompatActivity implements SensorEventListener {

    Button StopButton, startButton, tALGO_button;
    private SensorManager sensorManager;
    TextView OXcoor, OYcoor, NXcoor, NYcoor, GPSPosition;
    ImageView imgView;
    private LocationManager locationManager;
    private LocationListener locationListener;
    double Lon;
    double Lat;
    private int curX = -1, curY = -1; // mouse coorindates w.r.t. imageView
    private int navX = -1, navY = -1;
    private double aspx = 0, aspy = 0;  // scale: (image) / (screen)
    private final int MAPX = 563;
    private final int MAPY = 1328;
    public double xC = 0;
    public double yC = 0;
    public double xO = 0;
    public double yO = 0;
    public boolean pressed = false;
    private static final String TAG = "SensorActivity";
    public long StartTime;
    public long endTime;
    public long time;
    private Context contexts;
    public boolean started;
    public boolean initialized = false;
    public float gyroZ = 0;
    double noise[] = new double[3];
    float alpha = (float) 0.1;
    public double RotationAngle = 0;
    public boolean showLandmark = false;
    double[] mu;
    double[] TESTmu;
    double TxC, TyC;
    boolean tINITAL = true;
    String PCORD;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ekfslam);
        StopButton = findViewById(R.id.StopButton);
        startButton = findViewById(R.id.startButton);
        tALGO_button = findViewById(R.id.tALGO_button);
        OXcoor = findViewById(R.id.OXcoor);
        OYcoor = findViewById(R.id.OYcoor);
        NXcoor = findViewById(R.id.NXcoor);
        NYcoor = findViewById(R.id.NYcoor);
        GPSPosition = findViewById(R.id.GPSPosition);
        imgView = findViewById(R.id.imageView);
        Context contexts = this;
        PCORD = "0,0";
        ReadAndWrite readAndwrite = new ReadAndWrite();
        String data = null;
        try {
            data = readAndwrite.READLPos(EKFSLAM.this);
        } catch (IOException e) {
            e.printStackTrace();
        }
        String[] dataArray = data.split(",");


        noise[0] = 0;
        noise[1] = 0;
        noise[2] = 0;


        imgView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                //EditText mEdit;
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    curX = (int) event.getX();
                    curY = (int) event.getY();
                    //mEdit = (EditText)findViewById(R.id.editText1);
                    if ((aspx == 0) && (aspy == 0)) { // fixing the scale: image / screen
                        aspx = (1.0 * MAPX) / imgView.getWidth();
                        aspy = (1.0 * MAPY) / imgView.getHeight();
                    }

                    xC = (int) (aspx * curX);
                    yC = (int) (aspy * curY);

                    // get a reference to the imageView
                    draw();
                }
                return true;
            }
        });
        /* end of the image map click event detection */


        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                Lon = location.getLongitude();
                Lat = location.getLatitude();
                GPSPosition.setText("GPS Position: (" + Lon + "," + Lat + ")");
            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

                Intent i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(i);
            }
        };

        configure_button();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 10:
                configure_button();
                break;
            default:
                break;
        }
    }

    void configure_button() {
        // first check for permissions
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}
                        , 10);
            }
            return;
        }
        // this code won't execute IF permissions are not allowed, because in the line above there is return statement.

        tALGO_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (ActivityCompat.checkSelfPermission(EKFSLAM.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(EKFSLAM.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}
                                , 10);
                    }
                    return;
                }
                locationManager.requestLocationUpdates("gps", 500, 0, locationListener);

                xO = xC;
                OXcoor.setText("Old x Coordinate: "+xO/aspx);
                yO = yC;
                System.out.println("yC= "+yC);
                OYcoor.setText("Old y Coordinate: "+yO/aspy);
                ReadAndWrite readAndwrite = new ReadAndWrite();
                String data = null;
                try {
                    data = readAndwrite.READLPos(EKFSLAM.this);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String[] dataArray = data.split(",");
                int mSize = 3 + dataArray.length;
                TESTmu = new double[mSize];
                double [] TESTpose =new double[3];
                TESTmu[0] = xO;//setting the starting x position into mu
                TESTmu[1] = yO;//setting the starting y position into mu
                TESTmu[2] = 0;//setting the starting theta position into mu
                int n=0;

                for(int j=3;j<mSize;j++){
                    TESTmu[j] = Double.parseDouble(dataArray[j-3]);
                }

                System.out.println("testmu= "+TESTmu.length);

                double[][] TESTsigma = new double[mSize][mSize];


                double[] TESTodometries = new double[2];
                double xACC = 5;
                double yACC = -(5);// negative is up due to the canvas y axis increasing when you go down it
                double acel = Math.sqrt((xACC * xACC) + (yACC * yACC));
                double[] TESTomu = TESTmu;
                double[] bearing = new double[dataArray.length];
                time = 1;
                double speed = acel * time;
                TESTodometries[0] = speed;
                TESTodometries[1] = 0;//rotation set to 0

                for (int i = 0; i < dataArray.length/2; i++) {//getting the bearing for all landmarks for all positions
                    double difX = xO - Double.parseDouble((dataArray[2 * i]));
                    System.out.println("i="+i);
                    double difY = yO - Double.parseDouble((dataArray[2 * i + 1]));
                    double range = Math.sqrt((difX * difX) + (difY * difY));
                    double bearingangle = Math.atan(difY / difX);
                    bearing[2 * i] = range;
                    bearing[2 * i + 1] = bearingangle;
                }

                noise[0] = 0.01;
                noise[1] = 0.01;

                EKFSLAMalgo ekfslaMalgo = new EKFSLAMalgo();

                if (tINITAL){
                    PCORD=xO+","+yO;
                    TESTmu = ekfslaMalgo.belief_init_mu(dataArray.length / 2);
                    TESTsigma = ekfslaMalgo.belief_init_sigma(dataArray.length / 2);
                    tINITAL=false;
                }
                System.out.println("TESTmu after belief= "+TESTmu.length);
                TESTpose = ekfslaMalgo.prediction_step_mu(TESTsigma, TESTmu, TESTodometries, noise);
                TESTsigma = ekfslaMalgo.prediction_step_sigma(TESTsigma, TESTomu, TESTodometries, noise, dataArray.length / 2);
                TESTmu[0]=TESTpose[0];
                TESTmu[1]=TESTpose[1];
                TESTmu[2]=TESTpose[2];
                System.out.println("TESTmu 0= "+TESTmu[0]);
                System.out.println("TESTmu 1= "+TESTmu[1]);
                TESTomu = TESTmu;
                System.out.println("TESTmu after pred= "+TESTmu.length);
                TESTmu = ekfslaMalgo.correction_step_mu(TESTsigma, TESTmu, bearing, noise);
                TESTsigma = ekfslaMalgo.correction_step_sigma(TESTsigma, TESTomu, bearing, noise);
                xC = TESTmu[0];//new x coordinate
                yC = TESTmu[1];//new y coordinate
                TxC=xC;
                TyC=yC;


                draw();
                System.out.println("new x= "+TESTmu[0]/aspx);//new x coordinate);
                System.out.println("new y= "+TESTmu[1]/aspy);//new y coordinate
                NXcoor.setText("New x Coordinate: "+TESTmu[0]/aspx);
                NYcoor.setText("New y Coordinate: "+TESTmu[1]/aspy);
                PCORD = PCORD.concat("," + xC + "," + yC);

                draw();
            }
        });







        StopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pressed = false;

                Context context = getApplicationContext();
                CharSequence text = "Stopped!";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();


            }
        });

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(EKFSLAM.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(EKFSLAM.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}
                                , 10);
                    }
                    return;
                }
                locationManager.requestLocationUpdates("gps", 500, 0, locationListener);
                xO=xC;
                yO=yC;
                ReadAndWrite readAndwrite = new ReadAndWrite();
                String data = null;
                try {
                    data = readAndwrite.READLPos(EKFSLAM.this);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String[] dataArray = data.split(",");
                int mSize = 3 + dataArray.length;
                mu= new double [mSize];
                mu[0]=xO;//setting the starting x position into mu
                mu[1]=yO;//setting the starting y position into mu
                mu[2]=0;//setting the starting theta position into mu


                if (xO == 0 || yO == 0) {
                    Context context = getApplicationContext();
                    CharSequence text = "Choose a location to start on the map";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                } else {
                    pressed = true;
                    if (started){//checks if algorithm has already started

                    }else{
                        StartTime= System.nanoTime();
                    }
                }
            }
        });
    }


    public void draw(){
        Bitmap imageBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.map);
        // create a mutable bitmap with the same size as the imageView dimension
        Bitmap imageOverlay = Bitmap.createBitmap(imgView.getWidth(), imgView.getHeight(), Bitmap.Config.ARGB_8888);
        // create a canvas on which to draw
        Canvas canvas = new Canvas(imageOverlay);
        Paint p = new Paint();
        p.setColor(Color.BLUE);
        p.setFlags(Paint.ANTI_ALIAS_FLAG);
        /////////NAV CIRCLE__

        canvas.drawBitmap(imageBitmap, 0, 0, null);
        ////////______________
        //canvas.drawBitmap(imageBitmap, 0, 0, null);
        canvas.drawCircle(curX, curY, 10, p);

        Paint q = new Paint();
        q.setColor(Color.RED);
        q.setFlags(Paint.ANTI_ALIAS_FLAG);
        ReadAndWrite readAndwrite = new ReadAndWrite();
        String data = null;
        try {
            data = readAndwrite.READLPos(EKFSLAM.this);
        } catch (IOException e) {
            e.printStackTrace();
        }
        String[] dataArray = data.split(",");

        for(int i=0; i<dataArray.length/2;i++){
            int xd= Integer.parseInt(dataArray[2*i]);
            int yd= Integer.parseInt(dataArray[2*i+1]);
            float xf = (float) (xd/aspx);
            float yf = (float) (yd/aspy);
            canvas.drawCircle(xf, yf, 20, q);
        }

        Paint SavedT = new Paint();
        SavedT.setColor(Color.DKGRAY);
        SavedT.setFlags(Paint.ANTI_ALIAS_FLAG);

        String[] TdataArray = PCORD.split(",");
        for(int i=0; i<TdataArray.length/2;i++){
            System.out.println("i= "+i);
            System.out.println("TdataArray[2*i]=" +TdataArray[2*i]);
            double txd= Double.parseDouble(TdataArray[2 * i]);
            double tyd= Double.parseDouble(TdataArray[2*i+1]);
            float txf = (float) (txd/aspx);
            float tyf = (float) (tyd/aspy);
            canvas.drawCircle(txf, tyf, 5, SavedT);
        }


        Paint r = new Paint();
        r.setColor(Color.GREEN);
        r.setFlags(Paint.ANTI_ALIAS_FLAG);
        float XF = (float) (xO/aspx);
        float YF = (float) (yO/aspy);
        canvas.drawCircle(XF, YF, 20, r);


        Paint t = new Paint();
        t.setColor(Color.MAGENTA);
        t.setFlags(Paint.ANTI_ALIAS_FLAG);
        float TX = (float) (TxC/aspx);
        float TY = (float) (TyC/aspy);
        canvas.drawCircle(TX, TY, 10, t);


        imgView.setImageBitmap(imageOverlay);
    }


    @Override
    public void onAccuracyChanged(Sensor sensor,int accuracy){
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor = sensorEvent.sensor;
        ReadAndWrite readAndwrite = new ReadAndWrite();
        String data = null;
        try {
            data = readAndwrite.READLPos(EKFSLAM.this);
        } catch (IOException e) {
            e.printStackTrace();
        }
        String[] dataArray = data.split(",");
        int mSize = 3 + dataArray.length;
        double[][] sigma = new double[mSize][mSize];


        if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            //Log.d(TAG, "onSensorChanged: X:" + sensorEvent.values[0] + "Y: " + sensorEvent.values[1]);
            System.out.println("accel sensor part");

            //textView.setText("x=" + sensorEvent.values[0]);
            if (pressed){//if start SLandmarks_Button pressed
                System.out.println("pressed = true and in sensor part");
                double[] odometries = new double[2];
                double xACC=sensorEvent.values[0];
                double yACC=-(sensorEvent.values[1]);
                double acel =Math.sqrt((xACC*xACC)+(yACC*yACC));
                double [] omu = mu;
                double [] bearing= new double [dataArray.length];
                endTime = System.nanoTime();
                time = (endTime-StartTime)/1000000000;//to convert to seconds
                StartTime=endTime;
                double speed= acel*time;
                odometries[0]=speed;
                odometries[1]=gyroZ;

                for(int i=0;i<dataArray.length; i++){//getting the bearing for all landmarks for all positions
                    double difX = xO- Double.parseDouble((dataArray[2*i]));
                    double difY = yO- Double.parseDouble((dataArray[2*i+1]));
                    double range= Math.sqrt((difX*difX)+(difY*difY));
                    double bearingangle = Math.atan(difY/difX);
                    bearing[2*i]=range;
                    bearing[2*i+1]=bearingangle;
                }

                noise[0] = alpha * noise[0] + (1 - alpha) * sensorEvent.values[0];//gets noise for the x acceleration
                noise[1] = alpha * noise[1] + (1 - alpha) * sensorEvent.values[1];//gets noise for y acceleration


                EKFSLAMalgo ekfslaMalgo = new EKFSLAMalgo();
                System.out.println("Before if");
                if (started){//if algorithm has started then:
                    if(initialized){//if algorithm has initialized then:
                        mu=ekfslaMalgo.prediction_step_mu(sigma, mu,odometries,noise);
                        omu=mu;
                        sigma =ekfslaMalgo.prediction_step_sigma(sigma, omu,odometries,noise,dataArray.length/2);
                        omu=mu;
                        mu=ekfslaMalgo.correction_step_mu(sigma, mu, bearing, noise);
                        sigma=ekfslaMalgo.correction_step_sigma(sigma, omu, bearing, noise);
                        xC=mu[0];//new x coordinate
                        yC=mu[1];//new y coordinate

                    }else{//if algorithm has not initialized then:
                        initialized=true;
                        mu=ekfslaMalgo.belief_init_mu(dataArray.length/2);
                        sigma=ekfslaMalgo.belief_init_sigma(dataArray.length/2);
                        mu=ekfslaMalgo.prediction_step_mu(sigma, mu,odometries,noise);
                        omu=mu;
                        sigma =ekfslaMalgo.prediction_step_sigma(sigma, omu,odometries,noise,dataArray.length/2);
                        omu=mu;
                        mu=ekfslaMalgo.correction_step_mu(sigma, mu, bearing, noise);
                        sigma=ekfslaMalgo.correction_step_sigma(sigma, omu, bearing, noise);
                        xC=mu[0];//new x coordinate
                        yC=mu[1];//new y coordinate
                    }
                    draw();
                    System.out.println("xC= "+xC);
                    System.out.println("yC= "+yC);


                }else {//if algorithm has not started then:
                    //nothing
                }
            }

        } else if (sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            // x_gyro.setText("" + sensorEvent.values[2]);//Gyroscope left=(+) & right=(-)
            gyroZ = sensorEvent.values[2];
            RotationAngle=gyroZ;
            System.out.println("gyro sensor part");
            noise[2] = alpha * noise[2] + (1 - alpha) * sensorEvent.values[2];//gets noise for gyroscope
        }
    }
}


