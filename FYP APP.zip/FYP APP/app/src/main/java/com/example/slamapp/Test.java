package com.example.slamapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ShapeDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import android.view.MotionEvent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;


public class Test extends AppCompatActivity implements SensorEventListener {
    Button getGPS_button, save_button, SHPath_button, set_button;
    TextView x_acc, y_acc, x_gyro, xCoordinate, yCoordinate, z_acc, textView5;
    ImageView imgView;


    //For GPS____
    double Lon;
    double Lat;
    private LocationManager locationManager;
    private LocationListener locationListener;
    //_____

    private static final float NS2S = 1.0f / 1000000000.0f;
    private final float[] deltaRotationVector = new float[4];
    private float timestamp;

    private float[] angleM = new float[9];
    private float angle;

    float[] mGravity;
    float[] mGeomagnetic;

    private static final String TAG = "SensorActivity";
    private SensorManager sensorManager;
    private Sensor accelerometer, mGyro, mMagno;
    ;
    private int curX = -1, curY = -1; // mouse coorindates w.r.t. imageView
    private int navX = -1, navY = -1;
    private double aspx = 0, aspy = 0;  // scale: (image) / (screen)
    private final int MAPX = 563;
    private final int MAPY = 1328;
    public int xC = 0;
    public int yC = 0;
    private double rotation = 0;
    float noise[] = new float[2];
    float alpha = (float) 0.1;
    public double RotationAngle = 0;
    public double xAC = 0;
    public double yAC = 0;
    public double Nx = 0;
    public double Ny = 0;
    public double xSTART = 0;
    public double ySTART = 0;
    public boolean SETpressed=false;

    ShapeDrawable mDrawable = new ShapeDrawable();
    public static int x;
    public static int y;
    public String accCORD="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        getGPS_button = findViewById(R.id.getGPS_button);
        SHPath_button= findViewById(R.id.SHPath_button);
        set_button=findViewById(R.id.set_button);
        save_button = findViewById(R.id.save_button);
        x_acc = findViewById(R.id.x_acc);
        y_acc = findViewById(R.id.y_acc);
        z_acc = findViewById(R.id.z_acc);
        x_gyro = findViewById(R.id.x_gyro);
        textView5 = findViewById(R.id.textView5);
        xCoordinate = findViewById(R.id.xCoordinate);
        yCoordinate = findViewById(R.id.yCoordinate);
        imgView = findViewById(R.id.imageView);

        imgView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                //EditText mEdit;
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    curX = (int) event.getX();
                    curY = (int) event.getY();
                    //mEdit = (EditText)findViewById(R.id.editText1);
                    if ((aspx == 0) && (aspy == 0)) { // fixing the scale: image / screen
                        aspx = (1.0 * MAPX) / imgView.getWidth();
                        aspy = (1.0 * MAPY) / imgView.getHeight();
                    }
                    //mEdit.setText("x : " + String.valueOf(imgView.getWidth()));
                    //mEdit.setText("x : " + String.valueOf((int) (aspx * curX)));
                    xCoordinate.setText("X: " + String.valueOf((int) (aspx * curX)));
                    xC = (int) (aspx * curX);
                    //mEdit = (EditText)findViewById(R.id.editText2);
                    //mEdit.setText("y: " + String.valueOf(imgView.getHeight()));
                    //mEdit.setText("y: " + String.valueOf((int) (aspy * curY)));
                    yCoordinate.setText("y: " + String.valueOf((int) (aspy * curY)));
                    yC = (int) (aspy * curY);
                    //mEdit = (EditText)findViewById(R.id.editText3);
                    //mEdit.setText("z : " + String.valueOf((int) (curZ)));
                    // get a reference to the imageView
                    //accCORD=xC+","+yC;
                    //Nx=xC;
                    //Ny=yC;


                    draw();
                }
                return true;
            }
        });
        Log.d(TAG, "onCreate: Intializing Sensor Services");

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer != null) {
            sensorManager.registerListener(Test.this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
            Log.d(TAG, "onCreate: Registered accelerometer listener");
        } else {
            x_acc.setText("Accelerometer not supported");
            y_acc.setText("Accelerometer not supported");
        }
        mGyro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if (mGyro != null) {
            sensorManager.registerListener(Test.this, mGyro, SensorManager.SENSOR_DELAY_NORMAL);
            Log.d(TAG, "onCreate: Registered mGyro listener");
        } else {
            x_gyro.setText("Gyroscope not supported");
        }
        mMagno = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if (mMagno != null) {
            sensorManager.registerListener(Test.this, mMagno, SensorManager.SENSOR_DELAY_NORMAL);
            Log.d(TAG, "onCreate: Registered mMagno listener");
        } else {
            //xMagnoValue.setText("Magnetometer not supported");
            //yMagnoValue.setText("Magnetometer not supported");
            //zMagnoValue.setText("Magnetometer not supported");
        }

/////////////////////////
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                Lon = location.getLongitude();
                Lat = location.getLatitude();

                textView5.setText("" + Lon + "," + Lat);
                System.out.println(Lon + "+" + Lat);
            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) {

            }

            @Override
            public void onProviderEnabled(String s) {

            }

            @Override
            public void onProviderDisabled(String s) {

                Intent i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(i);
            }
        };
        configure_button();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 10:
                configure_button();
                break;
            default:
                break;
        }
    }

    void configure_button() {
        // first check for permissions
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}
                        , 10);
            }
            return;
        }
        // this code won't execute IF permissions are not allowed, because in the line above there is return statement.
        getGPS_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //noinspection MissingPermission
                locationManager.requestLocationUpdates("gps", 500, 0, locationListener);
                System.out.println("Button pressed");
            }
        });

        set_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SETpressed=true;

                    accCORD = xC + "," + yC;
                    Nx = xC;
                    Ny = yC;
                }
        });

        save_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (xC == 0 && yC == 0) {
                } else {
                    ReadAndWrite readAndwrite = new ReadAndWrite();
                    String file = "GPSLocation.txt";
                    readAndwrite.writeFile(Test.this, file, xC, yC, Lon, Lat);
                }
            }
        });


        SHPath_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                draw();


            }
        });
    }

    public void draw(){

        Bitmap imageBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.map);
        // create a mutable bitmap with the same size as the imageView dimension
        Bitmap imageOverlay = Bitmap.createBitmap(imgView.getWidth(), imgView.getHeight(), Bitmap.Config.ARGB_8888);
        // create a canvas on which to draw
        Canvas canvas = new Canvas(imageOverlay);
        Paint p = new Paint();
        p.setColor(Color.BLUE);
        p.setFlags(Paint.ANTI_ALIAS_FLAG);
        /////////NAV CIRCLE__

        canvas.drawBitmap(imageBitmap, 0, 0, null);
        ////////______________
        //canvas.drawBitmap(imageBitmap, 0, 0, null);
        canvas.drawCircle(curX, curY, 10, p);
        // set the bitmap into the ImageView

        Paint q = new Paint();
        q.setColor(Color.RED);
        q.setFlags(Paint.ANTI_ALIAS_FLAG);
        ReadAndWrite readAndwrite = new ReadAndWrite();
        String data = null;
        try {
            data = readAndwrite.READLPos(Test.this);
        } catch (IOException e) {
            e.printStackTrace();
        }
        String[] dataArray = data.split(",");

        for(int i=0; i<dataArray.length/2;i++){
            int xd= Integer.parseInt(dataArray[2*i]);
            int yd= Integer.parseInt(dataArray[2*i+1]);
            float xf = (float) (xd/aspx);
            float yf = (float) (yd/aspy);
            canvas.drawCircle(xf, yf, 20, q);
        }

        if (SETpressed){

            String[] accCORDArray = accCORD.split(",");

            Paint r = new Paint();
            r.setColor(Color.GREEN);
            r.setFlags(Paint.ANTI_ALIAS_FLAG);
            float xfac=0, yfac=0;


            for(int i=0; i<accCORDArray.length/2;i++){
                double xdac= Double.parseDouble(accCORDArray[2*i]);
                double ydac= Double.parseDouble(accCORDArray[2*i+1]);
                xfac = (float) ((xdac)/aspx);
                yfac = (float) ((ydac)/aspy);
                canvas.drawCircle(xfac, yfac, 5, r);
            }

            Paint s = new Paint();
            s.setColor(Color.YELLOW);
            s.setFlags(Paint.ANTI_ALIAS_FLAG);
            canvas.drawCircle(xfac, yfac, 7, s);

        }

        imgView.setImageBitmap(imageOverlay);

    }

    public void onSensorChanged(SensorEvent sensorEvent) {


        Sensor sensor = sensorEvent.sensor;

        if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {

            Log.d(TAG, "onSensorChanged: X:" + sensorEvent.values[0] + "Y: " + sensorEvent.values[1]);

            x_acc.setText("x=" + sensorEvent.values[0]);
            y_acc.setText("y=" + sensorEvent.values[1]);
            z_acc.setText("z=" + sensorEvent.values[2]);
            xAC = (11*(sensorEvent.values[0]-0.4));
            yAC = -(11*(sensorEvent.values[1]-0.4));

            double NxAC=xAC+Nx;
            double NyAC=yAC+Ny;

            if(NxAC<=MAPX && NxAC>=0 && NyAC<=MAPY && NyAC>=0) {

                Nx = NxAC;
                Ny = NyAC;
            }

            if (SETpressed) {
                String[] accCORDArray = accCORD.split(",");
                System.out.println("string = "+accCORD);
                int accLength = accCORDArray.length;
                System.out.println("length = "+accLength);
                double accX,accY;
                accX= Double.parseDouble(accCORDArray[accLength-2]);
                System.out.println("accX= "+accX);
                accY= Double.parseDouble(accCORDArray[accLength-1]);
                System.out.println("accY= "+accY);



                    accCORD = accCORD.concat("," + NxAC + "," + NyAC);

            }

            /*
            if (curX>0 && curY>0){
                draw(curX+(int)xAC,curY+(int)yAC);
            }
            */

            System.out.println("\n");
            System.out.println("_________________________________________");
            System.out.println("map x=  " + curX+(int)xAC);
            System.out.println("map y= " + curY+(int)yAC);
            System.out.println("_________________________________________");
            System.out.println("\n");

            noise[0] = alpha * sensorEvent.values[0] + (1 - alpha) * noise[0];//gets noise for the x acceleration
            noise[1] = alpha * sensorEvent.values[1] + (1 - alpha) * noise[1];//gets noise for y acceleration
            System.out.println("\n");
            System.out.println("_________________________________________");
            System.out.println("noise of x=  " + noise[0]);
            System.out.println("noise of y= " + noise[1]);
            float noiseX = sensorEvent.values[0] - noise[0];
            float noiseY = sensorEvent.values[1] - noise[1];

            System.out.println("no noise x=  " + noiseX);
            System.out.println("no noise y= " + noiseY);
            System.out.println("_________________________________________");
            System.out.println("\n");
            z_acc.setText("z=" + sensorEvent.values[2]);//forward(+) and back(-)

        } else if (sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            x_gyro.setText("" + sensorEvent.values[2]);//Gyroscope left=(+) & right=(-)
            float axisZ = sensorEvent.values[2];
            RotationAngle = axisZ;

            //if (1.0E-6<axisZ && axisZ<-1.0E-6){
            //rotation=rotation+axisZ;
            // x_gyro.setText("" +axisZ);
            //}
            //rotation=rotation+axisZ;
            //x_gyro.setText("" +axisZ);

        }
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
