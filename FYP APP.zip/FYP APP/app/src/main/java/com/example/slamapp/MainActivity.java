package com.example.slamapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button test_navbutton;
    Button ekfslam_navbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        test_navbutton = findViewById(R.id.test_navbutton);
        ekfslam_navbutton = findViewById(R.id.ekfslam_navbutton);

        test_navbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NAVtest();
            }
        });

        ekfslam_navbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NAVekfSLAM();
            }
        });
    }

    public void NAVtest(){
        Intent intent = new Intent(this, Test.class);
        startActivity(intent);
    }
    public void NAVekfSLAM(){
        Intent intent = new Intent(this, EKFSLAM.class);
        startActivity(intent);
    }

}