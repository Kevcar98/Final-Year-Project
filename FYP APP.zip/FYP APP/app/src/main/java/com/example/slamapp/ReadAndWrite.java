package com.example.slamapp;

import android.app.Activity;
import android.content.Context;
import android.os.Build;


import androidx.annotation.RequiresApi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;


public class ReadAndWrite extends Activity {
        String file = "LandmarksGPS.txt";
        String fileLP ="LandmarksPosition.txt";

    public void writeFile(Context context,String file, int xC, int yC, double Lon, double Lat) {
        String x = String.valueOf(xC);
        String y = String.valueOf(yC);
        //Saves x coordinate, y coordinate, Longitude, Latitude
        String GPSlocation = "" + Lon + "," + Lat + "";
        try {
            FileOutputStream fileOutputStream = context.openFileOutput(file, Context.MODE_APPEND);
            fileOutputStream.write(GPSlocation.getBytes());
            fileOutputStream.write(10);
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String landmark = "" + x + "," + y;
        try {
            FileOutputStream fileOutputStream = context.openFileOutput(fileLP, Context.MODE_APPEND);
            fileOutputStream.write(landmark.getBytes());
            fileOutputStream.write(10);
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

        public void writeFiles(Context context,String file,double degree) {

            //Saves x coordinate, y coordinate, Longitude, Latitude
            String location = "" + degree;
            try {
                FileOutputStream fileOutputStream = context.openFileOutput(file, Context.MODE_APPEND);
                fileOutputStream.write(location.getBytes());
                fileOutputStream.write(10);
                fileOutputStream.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    public int LinesinFile(Context context){
        int lines = 0;
        try {
            FileInputStream fis = context.openFileInput(fileLP);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                lines++;
            }
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return lines;
    }

    public String READLPos(Context context) throws IOException {
        String data="";
        FileInputStream fis = context.openFileInput(fileLP);
        InputStreamReader isr = new InputStreamReader(fis);
        BufferedReader bufferedReader = new BufferedReader(isr);
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            sb.append(line);
            data+=line+",";
        }
        return data;
    }

    public String READLgps(Context context) throws IOException {
        String data="";
        FileInputStream fis = context.openFileInput(fileLP);
        InputStreamReader isr = new InputStreamReader(fis);
        BufferedReader bufferedReader = new BufferedReader(isr);
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            sb.append(line);
            data+=line+",";
        }
        return data;
    }
}
